#include "testslib.h"
#include "csrMatrixMock.h"


void testInternalStorage()
{
    std::cout << "internal storage..." << std::flush;

    /*
        Возьмём обычную разреженную матрицу
        [ 1  0 4 5 ]
        [ 2 -1 0 0 ]
        [ 0  0 3 2 ]
        она будет храниться как
        rows:    [ 1, 4, 6, 8 ]
        columns: [ 1, 3, 4, 1, 2, 3, 4 ]
        values:  [ 1, 4, 5, 2, -1, 3, 2 ]
    */

    csrMatrixMock<int> m1(3, 4);
    m1.set(1, 1, 1)
            .set(4, 1, 3)
            .set(5, 1, 4)
            .set(2, 2, 1)
            .set(-1, 2, 2)
            .set(3, 3, 3)
            .set(2, 3, 4);

    std::vector<int> rowPointers1;
    rowPointers1.push_back(1);
    rowPointers1.push_back(4);
    rowPointers1.push_back(6);
    rowPointers1.push_back(8);
    //assertEquals<std::vector<int> >(rowPointers1, *(m1.getRowPointers()), "Неверные указатели на строку");

    std::vector<int> columnPointers1;
    columnPointers1.push_back(1);
    columnPointers1.push_back(3);
    columnPointers1.push_back(4);
    columnPointers1.push_back(1);
    columnPointers1.push_back(2);
    columnPointers1.push_back(3);
    columnPointers1.push_back(4);
    //assertEquals<std::vector<int> >(columnPointers1, *(m1.getColumnPointers()), "Неверные указатели на столбец");

    std::vector<int> values1;
    values1.push_back(1);
    values1.push_back(4);
    values1.push_back(5);
    values1.push_back(2);
    values1.push_back(-1);
    values1.push_back(3);
    values1.push_back(2);
    //assertEquals<std::vector<int> >(values1, *(m1.getValues()), "Неверное значение элемента");


    /*
        Матрица с пустой строкой
        [ 10 0 0 2 ]
        [  0 0 0 0 ]
        [  3 1 0 4 ]
        будет храниться как
        rows:    [ 1, 3, 3, 6 ]
        columns: [ 1, 4, 1, 2, 4 ]
        values:  [ 10, 2, 3, 1, 4 ]
    */

    csrMatrixMock<int> m2(3, 4);
    m2.set(10, 1, 1)
            . set(2, 1, 4)
            . set(3, 3, 1)
            . set(1, 3, 2)
            . set(4, 3, 4);

    std::vector<int> rowPointers2;
    rowPointers2.push_back(1);
    rowPointers2.push_back(3);
    rowPointers2.push_back(3);
    rowPointers2.push_back(6);
    //assertEquals<std::vector<int> >(rowPointers2, *(m2.getRowPointers()), "Неверные указатели на строку");

    std::vector<int> columnPointers2;
    columnPointers2.push_back(1);
    columnPointers2.push_back(4);
    columnPointers2.push_back(1);
    columnPointers2.push_back(2);
    columnPointers2.push_back(4);
    //assertEquals<std::vector<int> >(columnPointers2, *(m2.getColumnPointers()), "Неверные указатели на столбец");

    std::vector<int> values2;
    values2.push_back(10);
    values2.push_back(2);
    values2.push_back(3);
    values2.push_back(1);
    values2.push_back(4);
    //assertEquals<std::vector<int> >(values2, *(m2.getValues()), "Неверное значение элемента");


    /*
        После того, как мы добавили 1 ненулевой элемент в пустую строку:
        rows:    [ 1, 3, 4, 7 ]
        columns: [ 1, 4, 2, 1, 2, 4 ]
        values:  [ 10, 2, 5, 3, 1, 4 ]
     */

    csrMatrixMock<int> m3 = m2;
    m3.set(5, 2, 2);

    std::vector<int> rowPointers3;
    rowPointers3.push_back(1);
    rowPointers3.push_back(3);
    rowPointers3.push_back(4);
    rowPointers3.push_back(7);
    //assertEquals<std::vector<int> >(rowPointers3, *(m3.getRowPointers()), "Неверные указатели на строку");

    std::vector<int> columnPointers3;
    columnPointers3.push_back(1);
    columnPointers3.push_back(4);
    columnPointers3.push_back(2);
    columnPointers3.push_back(1);
    columnPointers3.push_back(2);
    columnPointers3.push_back(4);
    //assertEquals<std::vector<int> >(columnPointers3, *(m3.getColumnPointers()), "Неверные указатели на столбец");

    std::vector<int> values3;
    values3.push_back(10);
    values3.push_back(2);
    values3.push_back(5);
    values3.push_back(3);
    values3.push_back(1);
    values3.push_back(4);
    //assertEquals<std::vector<int> >(values3, *(m3.getValues()), "Неверное значение элемента");

    /*
        Когда мы из 2й строки удалили тот элемент (будет та же матрица, что и во 2м случае)
        rows:    [ 1, 3, 3, 6 ]
        columns: [ 1, 4, 1, 2, 4 ]
        values:  [ 10, 2, 3, 1, 4 ]
     */

    csrMatrixMock<int> m4 = m3;
    m4.set(0, 2, 2);

    //assertEquals<std::vector<int> >(rowPointers2, *(m4.getRowPointers()), "Неверные указатели на строку");
    //assertEquals<std::vector<int> >(columnPointers2, *(m4.getColumnPointers()), "Неверные указатели на столбец");
    //assertEquals<std::vector<int> >(values2, *(m4.getValues()), "Неверное значение элемента");

    std::cout << " OK" << std::endl;
}
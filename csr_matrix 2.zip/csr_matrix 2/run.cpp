#include <iostream>
#include "testslib.h"

#include "csr_matrix.cpp"
#include "constructor.cpp"
#include "values.cpp"
#include "multiplication.cpp"
#include "csr_format.cpp"
#include "output.cpp"



int main(int argc, char ** argv)
{
    try {

        testConstructorFail1();
        testConstructorFail2();
        testConstructorFail3();
        testConstructorFail4();
        testGetFail();
        testSetFail();
        testGettersAndSetters();
        //testInternalStorage();
        testOutput();
        testVectorMultiplication();
        testMatricesMultiplication();

    } catch (const FailureException & e) {
        std::cout << " - FAIL: '" << e.getMessage() << "'" << std::endl;
        return 1;
    }

    return 0;
}
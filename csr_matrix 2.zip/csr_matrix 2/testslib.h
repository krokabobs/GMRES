#ifndef __TESTSLIB_H__

#define	__TESTSLIB_H__

#include <string>
#include <utility>
#include <vector>
#include <cstring>
#include <sstream>
#include <iostream>
#include <typeinfo>
#include <exception>


class FailureException : public std::exception
{

public:

	explicit FailureException(std::string  message) : std::exception(), message(std::move(message))
	{}


	~FailureException() noexcept override
	= default;


	inline std::string getMessage() const
	{
		return this->message;
	}


protected:

	std::string message;

};


void assertException(const char * exceptionClass, void(*callback)())
{
	try {
		callback();

	}
	catch (const std::exception & e) {
		std::string actualClass(typeid(e).name());

		if (strstr(actualClass.c_str(), exceptionClass) == nullptr) {
			std::ostringstream oss;
			oss << "Exception class '" << exceptionClass << "' expected, but '" << actualClass << "' thrown.";

			throw FailureException(oss.str());
		}

		return;
	}

	throw FailureException("Exception expected but none thrown.");
}


template<typename T>
void assertEquals(const T & a, const T & b, const char * message = nullptr)
{
	if (a != b) {
		std::ostringstream oss;
		if (message == nullptr) {
			oss << "Objects not equal when they should be." << std::endl;

		}
		else {
			oss << message << std::endl;
		}

		oss << a << std::endl << "expected, but" << std::endl << b << " given";
		throw FailureException(oss.str());
	}
}


template<typename X, typename Y>
void assertEquals(const X & a, const Y & b, const char * message = nullptr)
{
	if (a != b) {
		std::ostringstream oss;
		if (message == nullptr) {
			oss << "Objects not equal when they should be." << std::endl;

		}
		else {
			oss << message << std::endl;
		}

		oss << a << std::endl << "expected, but" << std::endl << b << " given";
		throw FailureException(oss.str());
	}
}

#endif

#include "testslib.h"
#include "csrMatrixMock.h"
#include "helpers.h"


void testVectorMultiplication()
{
	for (int N = 0; N < 5e3; N++) {
		std::cout << "\rvector multiplication... #" << N + 1 << std::flush;

		// генерируем рандомные матрицу и вектор
		int rows = rand() % 16 + 1;
		int cols = rand() % 16 + 1;

		std::vector<int> vec = generateRandomVector<int>(cols);

		std::vector<std::vector<int> > classicMatrix = generateRandomMatrix<int>(rows, cols);
		csrMatrixMock<int> csrMatrix = csrMatrixMock<int>::fromVectors(classicMatrix);

		// считаем результат вручную
		std::vector<int> manualResult = multiplyMatrixByVector(classicMatrix, vec);

		// используем метод класса
		assertEquals<std::vector<int> >(manualResult, csrMatrix.multiply(vec), "Incorrect vector multiplication");

		// используем *
		assertEquals<std::vector<int> >(manualResult, csrMatrix * vec, "Incorrect vector multiplication (operator *)");
	}

	std::cout << " OK" << std::endl;
}


void testMatricesMultiplication()
{
	for (int N = 0; N < 5e3; N++) {
		std::cout << "\rmatrices multiplication... #" << N + 1 << std::flush;

		// генерируем рандомные матрицы
		int rowsA = rand() % 16 + 1;
		int colsArowsB = rand() % 16 + 1;
		int colsB = rand() % 16 + 1;

		std::vector<std::vector<int> > classicMatrixA = generateRandomMatrix<int>(rowsA, colsArowsB);
		csrMatrixMock<int> csrMatrixA = csrMatrixMock<int>::fromVectors(classicMatrixA);

		std::vector<std::vector<int> > classicMatrixB = generateRandomMatrix<int>(colsArowsB, colsB);
		csrMatrixMock<int> csrMatrixB = csrMatrixMock<int>::fromVectors(classicMatrixB);

		// считаем результат
		std::vector<std::vector<int> > manualResult = multiplyMatrices(classicMatrixA, classicMatrixB);

		// проверяем
		assertEquals<csrMatrix::csrMatrix<int>, std::vector<std::vector<int> > >(
			csrMatrixA.multiply(csrMatrixB),
			manualResult,
			"Incorrect matrices multiplication"
			);

		assertEquals<csrMatrix::csrMatrix<int>, std::vector<std::vector<int> > >(
			csrMatrixA * csrMatrixB,
			manualResult,
			"Incorrect matrices multiplication (operator *)"
			);
	}

	std::cout << " OK" << std::endl;
}
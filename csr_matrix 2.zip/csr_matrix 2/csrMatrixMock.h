#ifndef __CSRMATRIX_MOCK_H__

#define __CSRMATRIX_MOCK_H__

#include <vector>
#include "csr_matrix.h"

template <typename T>
class csrMatrixMock : public csrMatrix::csrMatrix<T>
{

public:

	explicit csrMatrixMock(int n) : csrMatrix::csrMatrix<T>(n)
	{}


	csrMatrixMock(int rows, int columns) : csrMatrix::csrMatrix<T>(rows, columns)
	{}


	std::vector<T> * getValues()
	{
		return this->vals;
	}



	std::vector<int> * getColumnPointers()
	{
		return this->cols;
	}



	std::vector<int> * getRowPointers()
	{
		return this->rows;
	}


	static csrMatrixMock<T> fromVectors(std::vector<std::vector<T> > vec)
	{
		csrMatrixMock<T> matrix(vec.size(), vec[0].size());

		for (int i = 0, len = vec.size(); i < len; i++) {
			for (int j = 0, len = vec[i].size(); j < len; j++) {
				matrix.set(vec[i][j], i + 1, j + 1);
			}
		}

		return matrix;
	}

};


template<typename T>
bool operator == (const csrMatrix::csrMatrix<T> & sparse, const std::vector<std::vector<T> > & classical)
{
	for (int i = 0, rows = classical.size(); i < rows; i++) {
		for (int j = 0, cols = classical[i].size(); j < cols; j++) {
			if (sparse.get(i + 1, j + 1) != classical[i][j]) {
				return false;
			}
		}
	}

	return true;
}

#endif

#ifndef __CSRMATRIX_MOCK_H__

#define __CSRMATRIX_MOCK_H__

#include <vector>
#include "csr_matrix.h"

template <typename T>
class csrMatrixMock : public csrMatrix::csrMatrix<T>
{

public:

	csrMatrixMock(int n) : csrMatrix::csrMatrix<T>(n)
	{}


	csrMatrixMock(int rows, int columns) : csrMatrix::csrMatrix<T>(rows, columns)
	{}


	std::vector<T> * getValues(void)
	{
		return this->vals;
	}



	std::vector<int> * getColumnPointers(void)
	{
		return this->cols;
	}



	std::vector<int> * getRowPointers(void)
	{
		return this->rows;
	}


	void printInfo(std::ostream & os) const
	{
		std::vector<int>::iterator intIt;

		os << "rows (" << this->rows->size() << "): [";

		for (intIt = this->rows->begin(); intIt < this->rows->end(); intIt++) {
			if (intIt > this->rows->begin()) {
				os << ", ";
			}

			os << *intIt;
		}

		os << "]";

		os << std::endl << "cols";
		if (this->cols == NULL) {
			os << ": NULL";

		}
		else {
			os << " (" << this->cols->size() << "): [";

			for (intIt = this->cols->begin(); intIt < this->cols->end(); intIt++) {
				if (intIt > this->cols->begin()) {
					os << ", ";
				}

				os << *intIt;
			}

			os << "]";
		}

		os << std::endl << "vals";
		if (this->vals == NULL) {
			os << ": NULL";

		}
		else {
			typename std::vector<T>::iterator valIt;

			os << " (" << this->vals->size() << "): [";

			for (valIt = this->vals->begin(); valIt < this->vals->end(); valIt++) {
				if (valIt > this->vals->begin()) {
					os << ", ";
				}

				os << *valIt;
			}

			os << "]";
		}
	}


	static csrMatrixMock<T> fromVectors(std::vector<std::vector<T> > vec)
	{
		csrMatrixMock<T> matrix(vec.size(), vec[0].size());

		for (int i = 0, len = vec.size(); i < len; i++) {
			for (int j = 0, len = vec[i].size(); j < len; j++) {
				matrix.set(vec[i][j], i + 1, j + 1);
			}
		}

		return matrix;
	}

};


template<typename T>
bool operator == (const csrMatrix::csrMatrix<T> & sparse, const std::vector<std::vector<T> > & classical)
{
	for (int i = 0, rows = classical.size(); i < rows; i++) {
		for (int j = 0, cols = classical[i].size(); j < cols; j++) {
			if (sparse.get(i + 1, j + 1) != classical[i][j]) {
				return false;
			}
		}
	}

	return true;
}

#endif

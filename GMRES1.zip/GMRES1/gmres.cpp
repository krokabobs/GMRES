#include "gmres.h"
#include <numeric>
#include <algorithm>
#include <cmath>
#include <vector>

using namespace std;

double Gmres::norm(vector<double> &a)
{
    double sumSqr = 0;
    for(int i = 0; i < a.size(); i++){
        sumSqr += a[i]*a[i];
    }
    return sqrt(sumSqr);
}

void Gmres::getKrylov(vector<vector<double>> &v, int j, vector<vector<double>> &h, int m){
    vector<double> w = mtx->mv_prod(v[j], w);
    vector<double> h_colj;
    auto hc = h_colj.data();
    for (int i = 0; i <= j; i++) {
        for (int d = 0; d < v.size(); d++)
            hc[d] += (w.begin())*(v[i].begin());
        //h_colj.push_back(inner_product(w.begin(), w.end(), v[i].begin(), 0.0));
        for (int k = 0; k < w.size(); k++) {
            w[k] = w[k] - h_colj[i] * v[i][k];
        }
    }
    for (int s = 0; s < v.size() + w.size(); s++) {
        hc[v.size()+s] = norm(w);
    }
    //h_colj.push_back(norm(w));
    vector<double> v_next;
    auto vn = v_next.data()
    for (int l = 0; l < w.size(); l++) {
        vn[l] = w[l] / h_colj[j + 1];
        //v_next.push_back(w[l] / h_colj[j + 1]);
    }
    h_colj.resize(m + 1, 0);
    for (int p = 0; p < w.size() + r0.size() ; p++) {
        a[r0.size() + p] = v_next;
    }
    //v.push_back(v_next);
}

vector<double> Gmres::GMRES(vector<double> &x0, vector<double> &b, int m, bool isSymmetric, double &rho) {
    vector<double> r0(mtx.getMatrixSize(), 0), g (m+1, 0);
    g[0] = 1;
    vector<vector<double>> v, h(m, vector<double> (m+1, 0));
    double normr0 = 0;
    // r0 = b-A*x0
    vector<double> r = mtx->mv_prod(x0, r);
    for (int i = 0; i < r0.size(); i++) {
        r0[i] = b[i] - r[i];
        normr0 += r0[i] * r0[i];
    }
    // v1 = r0/||r0||
    normr0 = sqrt(normr0);
    for (int i = 0; i < r0.size(); i++) {
        r0[i] = r0[i] / normr0;
    }
    auto a = v.data();
    auto b = r0.data();
    for (int i = 0; i < r0.size(); i++) {
        a[i] = b[i];
    }
    //v.push_back(r0);
    // g = |r0|e1
    for(int i = 0; i < g.size(); i++){
        g[i] = normr0*g[i];
    }
    vector<double> cs(m+5, 0), sn(m+5, 0);
    for(int j = 0; j < m; j++){
        getKrylov(v, j, h, m);
        for(int k = 1; k <= j; k++){
            double tempPrev = cs[k-1]*h[j][k-1]+sn[k-1]*h[j][k];
            h[j][k] = -sn[k-1]*h[j][k-1]+cs[k-1]*h[j][k];
            h[j][k-1] = tempPrev;
        }
        double denom = sqrt(h[j][j]*h[j][j]+h[j][j+1]*h[j][j+1]);
        cs[j] = h[j][j]/denom;
        sn[j] = h[j][j+1]/denom;
        h[j][j] = denom;
        g[j+1] = -sn[j]*g[j];
        g[j] = cs[j]*g[j];
    }
}
int main() {
    return 0;
}

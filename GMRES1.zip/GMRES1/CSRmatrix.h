#ifndef GMRES_ILU0_CSRMATRIX_H
#define GMRES_ILU0_CSRMATRIX_H
#include <vector>
using namespace std;
enum ReadState{
    PARAMS = 0,
    VALS
};

/*!
 * \class CSRmatrix
 * \brief Base interface class for CSR matrix
 * \details Base interface class for CSR matrix
 *          has function for initialization matrix
 *          and some operations
 */
class CSRmatrix {
public:
    //!constructor
    CSRmatrix ();
    //!destructor
    ~CSRmatrix ();

    /*!
    * \brief initialization CSR matrix
     * \param[in] size - size of matrix
     * \param[in] non_zero - non zero elements in matrix
     * \bsize[in] bsize - block size
    */
    int InitMatrix (int size, int non_zero, int bsize);
    /*!
    * \brief initialization CSR matrix by parent matrix
     * \param[in] matrix - parent csr matrix
    */

    //! Getter methods
    double getValues ();
    vector<double> getVal ();
    int getColNum ();
    vector<int> getCols ();
    int getRowInd ();
    vector<int> getRows ();
    int getMatrixSize () const { return matrix_size; }
    int getBlockSize () const { return block_size; }
    int getNnz () const { return nnz; }
    int getPostDiagRowInd ();
    vector<int> getPDRI ();
    /*!
    * \brief Read and generation CSR matrix from file
     * \param[in] filename - file with matrix
     * \param[in] bs - block size of the matrix
    */
    int ReadMatrixFromFile(const char *filename, const int bs);
    /*!
    * \brief Write CSR matrix to file
     * \param[in] filename - file to write
    */
    int WriteMatrixToFile(const char *filename);

    /*!
    * \brief Matrix vector product operation r = Ax
     * \param[in] x - input array
     * \param[in] r - result
    */
    void mv_prod(vector<double> &x, vector<double> &r);
    vector<double> result;

private:
    int matrix_size;     //!< size of the matrix (n*n)
    int block_size;      //!< block size of the matrix
    int nnz;             //!< non zero elements in matrix
    vector<double> values;      //!< matrix values (size: nnz)
    vector<int> col_num;        //!< array of column numbers (size: nnz)
    vector<int> row_ind;        //!< array of string indices (size: n+1)
    vector<int> post_diag_row_ind;   //!< array next of the diagonal row index
};
#endif //GMRES_ILU0_CSRMATRIX_H

//
// Created by Павел Филиппов on 10.12.2021.
//
#include "CSRmatrix.h"
#include <vector>

int main()
{
    CSRmatrix A;
    A.ReadMatrixFromFile ("~/Downloads/CSR/full0.mm", 2);
    std::vector<double> result;
    std::vector<double> vals = A.getVal();
    A.mv_prod(vals,result);
    A.WriteMatrixToFile ("~/Downloads/CSR/res.mm");
    return 0;
};

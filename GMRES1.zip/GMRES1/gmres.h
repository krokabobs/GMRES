//
// Created by Павел Филиппов on 13.12.2021.
//

#ifndef GMRES1_GMRES_H
#define GMRES1_GMRES_H
#include <cfloat>
#include <cstdint>
#include "CSRmatrix.h"
#include "matrix.h"
#include <vector>
using namespace std;

class Gmres {
public:
    Gmres() = default;
    ~Gmres() = default;
    double norm (vector<double> &a);
    vector<double> GMRES(vector<double> &x0, vector<double> &b, int m, int j, bool isSymmetric, double &rho);
private:
    CSRmatrix &mtx;
};
#endif //GMRES1_GMRES_H

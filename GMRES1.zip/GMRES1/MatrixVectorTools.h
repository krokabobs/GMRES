#ifndef GMRES_ILU0_MATRIXVECTORTOOLS_H
#define GMRES_ILU0_MATRIXVECTORTOOLS_H

#include <cmath>

//! LU decomposition for blocks
inline void LU_decomp(int n, double *m) {
  for (int i = 1; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      double sum = 0;
      for (int k = 0; (k < i) && (k < j); ++k) {
        sum += m[i * n + k] * m[k * n + j];
      }
      m[i * n + j] -= sum;
      if (j < i)
        m[i * n + j] /= m[j + j * n];
    }
  }
}

//! find solution for lower triangular matrix (U*x = L^-1*b)
inline void LU_find_sol_L(const int n, const double *L_block, double *res) {
  for (int i = 1; i < n; ++i) {
    for (int j = 0; j < i; ++j) {
      res[i] -= L_block[i * n + j] * res[j];
    }
  }
}

//! find solution for upper triangular matrix (x = U^-1*L^-1*b)
inline void LU_find_sol_U(const int n, const double *U_block, double *res) {
  for (int i = n - 1; i >= 0; --i) {
    for (int j = n - 1; j > i; --j) {
      res[i] -= U_block[i * n + j] * res[j];
    }
    res[i] /= U_block[i + i * n];
  }
}

inline void LU_solve(const int n, const double *block, double *res)
{
  //calculate solution x = U^-1*L^-1
  LU_find_sol_L(n, block, res);
  LU_find_sol_U(n, block, res);
}

//! find L matrix in LU factorization (solve LU = A for unknown L)
inline void LU_fact_L (int n, double *u, double *l) {
  for (int j = 0; j < n; ++j) {
    for (int i = 0; i < n; ++i) {
      l[j + i * n] /= u[j + j * n];
      for (int k = j + 1; k < n; ++k) {
        l[k + i * n] -= l[j + i * n] * u[k + j * n];
      }
    }
  }
}

//! find U matrix in LU factorization (solve LU = A for unknown U)
inline void LU_fact_U (int n, double *l, double *u) {
  for (int i = 1; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      for (int k = 0; k < i; ++k) {
        u[j + i * n] -= l[k + i * n] * u[j + k * n];
      }
    }
  }
}

//! LU factorization for n x n block
inline void LU_fact (int n, double *m) {
  for (int i = 1; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      double sum = 0;
      for (int k = 0; (k < i) && (k < j); ++k) {
        sum += m[k + i * n] * m[j + k * n];
      }
      m[j + i * n] -= sum;
      if (j < i)
        m[j + i * n] /= m[j + j * n];
    }
  }
}

//! calculate A = A - L*U
inline void LU_update (int n, double *l, double *u, double *b) {
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      const double v = l[j + i * n];
      for (int k = 0; k < n; ++k) {
        b[k + i * n] -= v * u[k + j * n];
      }
    }
  }
}

//! update for solution
inline void LU_find_root (int n, const double *m, const double *v, double *r) {
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      r[i] -= m[j + i * n] * v[j];
    }
  }
}

//! find solution for lower triangular L matrix with 1 on diagonal
inline void LU_find_root_l (int n, const double *l, double *v) {
  for (int i = 1; i < n; ++i) {
    for (int j = 0; j < i; ++j) {
      v[i] -= l[j + i * n] * v[j];
    }
  }
}

//! find solution for upper triangular U matrix
inline void LU_find_root_u (int n, const double *u, double *v) {
  for (int i = n - 1; i >= 0; --i) {
    for (int j = n - 1; j > i; --j) {
      v[i] -= u[j + i * n] * v[j];
    }
    v[i] /= u[i + i * n];
  }
}

inline void vv_prod_m(const int n, const double *v1, const double *v2, double& r)
{
  for (int i = 0; i < n; ++i){
    r -= v1[i] * v2[i];
  }
}

inline void vv_prod_p (const int n, const double *v1, const double *v2, double& r){
  for (int i = 0; i < n; ++i){
    r += v1[i] * v2[i];
  }
}

//for test
inline void gauss (int n, double* v)
{
  double mult = v[5] / v[8];
  v[4] -= v[7] * mult;
  v[3] -= v[6] * mult;
  mult = v[2] / v[8];
  v[0] -= v[6] * mult;
  v[1] -= v[7] * mult;
  mult = v[1] / v[4];
  v[0] -= v[3] * mult;
  v[2] = 0;
  v[1] = 0;
  v[5] = 0;
}

inline double vv_product(const double *v1, const double *v2, const int n)
{
  double sum = 0;
  for (int i = 0; i < n; i++){
    sum += v1[i] * v2[i];
  }
  return sum;
}

inline void vv_sum(double *v, const double s, const double *u, const int n)
{
  for (int i = 0; i < n; i++)
    v[i] += s * u[i];
}


inline void sv_product(double *v, const double s, const int n)
{
  for (int i = 0; i < n; i++)
    v[i] *= s;
}

inline double calc_norm(const double *v, const int n)
{
  return sqrt(vv_product(v, v, n));
}

//! compute matrix x vector product
inline void mv_product (const int n, const double *m, const double *v, double *r)
{
  for (int i = 0; i < n; ++i){
    double sum = 0;
    for (int j = 0; j < n; ++j){
      sum += m[j + i * n] * v[j];
    }
    r[i] += sum;
  }
}

#endif //GMRES_ILU0_MATRIXVECTORTOOLS_H

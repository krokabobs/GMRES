#include "CSRmatrix.h"
#include <iostream>
#include <vector>
#include <set>
#include "MatrixVectorTools.h"

CSRmatrix::CSRmatrix () {
  matrix_size = 0;
  block_size = 0;
  nnz = 0;
}

CSRmatrix::~CSRmatrix () = default;

double CSRmatrix::getValues () {
    for (unsigned int i = 0; i < values.size(); i++)
        return values[i];
    return 0;
}

vector<double> CSRmatrix::getVal () {
    return values;
}

int CSRmatrix::getColNum() {
    for (unsigned int i = 0; i < col_num.size(); i++)
        return col_num[i];
    return 0;
}

vector<int> CSRmatrix::getCols () {
    return col_num;
}

int CSRmatrix::getRowInd() {
    for (unsigned int i = 0; i < row_ind.size(); i++)
        return row_ind[i];
    return 0;
}

vector<int> CSRmatrix::getRows () {
    return row_ind;
}

int CSRmatrix::getPostDiagRowInd (){
    for (unsigned int i = 0; i < post_diag_row_ind.size(); i++)
        return post_diag_row_ind[i];
    return 0;
}

vector<int> CSRmatrix::getPDRI () {
    return post_diag_row_ind;
}

int CSRmatrix::InitMatrix (const int size, const int non_zero, const int bsize) {
  if (size < 1) {
    std::cout << "Error: size of matrix = 0!";
    return -1;
  }
  if (non_zero < 1) {
    std::cout << "Error: non zero elements in matrix = 0!";
    return -1;
  }
  if (bsize < 1) {
    std::cout << "Error: block size of the matrix = 0!";
    return -1;
  }
  matrix_size = size;
  nnz = non_zero;
  block_size = bsize;
  values.reserve(non_zero);
  col_num.reserve(non_zero);
  post_diag_row_ind.reserve(size-1);
  row_ind.reserve(size+1);
  return 0;
}

int CSRmatrix::ReadMatrixFromFile (const char *filename, const int bs) {
  char buf[4096];
  char *start_ptr = nullptr, *end_ptr = nullptr;
  int nr = 0, nnz = 0, nc = 0;
  auto state = PARAMS;
  int row_ptr = 0;
  int count = 0, row_counter = 1;
  int col_ind = 0;
  double val = 0.;
  block_size = bs;
  int bs_sqr = block_size * block_size;
  double *block_val;
  std::vector<int> ja;
  double *a;
  std::vector<std::vector<int>> matrix_struct;

  auto rows_ptr = row_ind.data();
  auto values_ptr = values.data();
  auto cols_ptr = col_num.data();
  FILE *file = fopen(filename, "r");
  if (!file){
    std::cout << "Error: Can't open file!" << "\n";
    return -1;
  }

  while (fgets(buf, 4096, file)){
    if (state == PARAMS){
      if (!strncmp(buf, "%%", 2))
        continue;
      start_ptr = buf;
      nr = (int) strtol(start_ptr, &end_ptr, 10);
      if (start_ptr == end_ptr)
        continue;
      start_ptr = end_ptr;
      nc = (int) strtol(start_ptr, &end_ptr, 10);
      if (start_ptr == end_ptr)
        continue;
      start_ptr = end_ptr;
      nnz = (int) strtol(start_ptr, &end_ptr, 10);
      a = new double[nnz];
      nr /= block_size;
      nnz /= bs_sqr;
      if (InitMatrix(nr, nnz, block_size)){
        std::cout << "Error: Can't allocated matrix from file!\n";
        return -1;
      }
      state = VALS;
    }
    else if (state == VALS){
      start_ptr = buf;
      row_ptr = (int) strtol(start_ptr, &end_ptr, 10);
      if (start_ptr == end_ptr)
        continue;
      start_ptr = end_ptr;
      col_ind = (int) strtol(start_ptr, &end_ptr, 10) - 1;
      if (start_ptr == end_ptr)
        continue;
      start_ptr = end_ptr;
      val = strtod(start_ptr, &end_ptr);
      if (start_ptr == end_ptr)
        continue;

      if (col_ind % block_size == 0 && row_ptr % block_size == 0){
        ja.push_back(col_ind / block_size);
      }
      if (row_ptr > row_counter * block_size){
        matrix_struct.push_back(ja);
        ja.clear();
        row_counter++;
      }
      a[count++] = val;
    }
  }
  matrix_struct.push_back(ja);
  count = 0;
  double *a_block;
  int a_shift;
  for (int i = 0; i < nr; i++){
    int n_cols = matrix_struct[i].size();
    auto row_i = row_ind[i];
    row_ind[i + 1] = row_i + n_cols;
    a_block = a + row_i * bs_sqr;
    count = 1;
    for (int j = 0; j < n_cols; j++){
      auto col = matrix_struct[i][j];
      if (i != col){
        block_val = values_ptr + row_i * bs_sqr + count * bs_sqr;
        col_num[row_i + count] = col;
        count++;
      }
      else{
        block_val = values_ptr + row_i * bs_sqr;
        col_num[row_i] = i;
      }
      for (int k = 0; k < block_size; k++){
        a_shift = k * n_cols * block_size + j * block_size;
        for (int kk = 0; kk < block_size; kk++){
          block_val[k * block_size + kk] = a_block[kk + a_shift];
        }
      }
    }
  }
  int j_start, j_end;
  for (int i = 0; i < nr; i++){
    j_start = row_ind[i] + 1;
    j_end = row_ind[i + 1];
    post_diag_row_ind[i] = j_end;
    for (auto j = j_start; j < j_end; j++){
      if (col_num[j] > i){
        post_diag_row_ind[i] = j;
        break;
      }
    }
    //std::cout << "pde_num = " << post_diag_row_ind[i] << "\n";
  }
  delete[] a;
  fclose(file);
  return 0;
}

void CSRmatrix::mv_prod (vector<double> &x, vector<double> &r) {
  double *r_block, *m_block;
  const double *x_block;
  int j_start = 0, j_end = 0, j = 0, col = 0;
  auto bs_sqr = block_size * block_size;
  auto values_ptr = values.data();
  auto x1 = x.data();
  auto r1 = r.data();
  for (int i = 0; i < matrix_size; i++){
    r_block = r1 + i * block_size;
    j_start = row_ind[i];
    j_end = row_ind[i + 1];
    for (j = j_start; j < j_end; j++){
      col = col_num[j];
      m_block = values_ptr + j * bs_sqr;
      x_block = x1 + col * block_size;
      mv_product(block_size, m_block, x_block, r_block);
    }
  }
}

int CSRmatrix::WriteMatrixToFile (const char *filename) {
  auto bs_sqr = block_size * block_size;
  FILE *file = fopen(filename, "w");
  if (!file){
    std::cout << "Error: Can't open file!" << "\n";
    return -1;
  }
  fprintf (file, "%% N_ROWS\tN_NON_ZEROS\tN_BLOCK_SIZE\n");
  fprintf (file, "%d\t%d\t%d\n", matrix_size, nnz, block_size);
  fprintf (file, "%% Rows indexes[1..n_rows]\n");
  for (int i = 1; i <= matrix_size; ++i)
    fprintf (file, "%d\n", row_ind[i]);
  fprintf (file, "%% END of Rows indexes\n");
  fprintf (file, "%%COLUMN\tVALUE\n");
  for (int i = 0; i < matrix_size; ++i) {
    fprintf(file, "%% ROW %d\n", i);
    auto j_start = row_ind[i];
    auto j_end = row_ind[i + 1];
    for (auto j = j_start; j < j_end; ++j) {
      fprintf(file, "%d", col_num[j]);
      auto jj_start = j * bs_sqr;
      auto jj_end = jj_start + bs_sqr;
      for (auto jj = jj_start; jj < jj_end; ++jj) {
        fprintf(file, "\t%.10lf", values[jj]);
      }
      fprintf(file, "\n");
    }
  }
  fprintf (file, "%% END OF FILE\n");
  fclose(file);
  return 0;
}
#include "CRSmatrix.h"

CRSmatrix::CRSmatrix(std::vector<double> v, std::vector<int> r, std::vector<int> c) {
    value = v;
    rowPtr = r;
    colInd = c;

    //число строк
    rowNum = rowPtr.size() - 1;

    //число столбцов
    colNum = 0;
    for (unsigned int i = 0; i < colInd.size(); i++) {
        if (colInd[i] > colNum) {
            colNum = colInd[i];
        }
    }
    colNum++;
}

CRSmatrix::CRSmatrix(std::string valueFilePath, std::string rowPtrFilePath, std::string colIndFilePath) {
    //Read in files
    std::ifstream rowFile, valueFile, colFile;

    rowFile.open(rowPtrFilePath);
    valueFile.open(valueFilePath);
    colFile.open(colIndFilePath);

    // Check if the file is open
    if (!rowFile || !valueFile || !colFile) {
        std::cout << "Unable to open file" << std::endl;
        exit(1);
    }

    // Declare a variable to load the contents from the file
    std::string line = "";

    // Loading the value vector
    std::string myValue;
    while (valueFile.good()) {
        getline(valueFile, myValue, '\n');
        //convert string value to double value
        double myDoubleValue = atof(myValue.c_str());
        value.push_back(myDoubleValue);
    }

    // Loading the row pointer vector
    while (rowFile >> line) {
        int rowNum = stoi(line);
        rowPtr.push_back(rowNum);
    }

    // Loading the column indice vector
    while (colFile >> line) {
        int colIndex = stoi(line);
        colInd.push_back(colIndex);
    }

    //find total number of rows
    rowNum = rowPtr.size() - 1;

    //find total number of columns
    colNum = 0;
    for (unsigned int i = 0; i < colInd.size(); i++) {
        if (colInd[i] > colNum) colNum = colInd[i];
    }
    colNum++;
}

CRSmatrix::CRSmatrix(int r, int c) {
    rowNum = r;
    colNum = c;
}

int CRSmatrix::getRowSize() {
    return rowNum;
}

int CRSmatrix::getColSize() {
    return colNum;
}

double CRSmatrix::retrieveElement(unsigned int i, unsigned int j) {
    int pos = rowPtr[i];
    bool found = 0;
    for (int n = rowPtr[i]; n < rowPtr[i] + (rowPtr[i + 1] - rowPtr[i]); n++) {
        if (colInd[n] == j) {
            pos = n;
            found = 1;
        }
    }
    if (found) return value[pos];
    return 0.0;
}

void CRSmatrix::changeValue(double x, unsigned int i, unsigned int j) {
    if (value.empty()) {
        value.push_back(x);
        colInd.push_back(j);
        rowPtr.push_back(0);
        rowPtr.push_back(1);
    } else {
        value.push_back(x);
        colInd.push_back(j);
        if (rowPtr.size() <= i + 1)
            rowPtr.push_back(value.size());
        else
            rowPtr[rowPtr.size() - 1] = rowPtr[rowPtr.size() - 1] + 1;
    }
}

std::vector<double> CRSmatrix::productAx(std::vector<double> x) {
    std::vector<double> product(x.size());
    for (int i = 0; i < rowNum; i++) {
        for (int j = 0; j < colNum; j++) {
            product[i] += x[j] * retrieveElement(i, j);
        }
    }
    return product;
}

void CRSmatrix::deleteValue(unsigned int i, unsigned int j) {
    for (int n = rowPtr[i]; n < rowPtr[i] + (rowPtr[i + 1] - rowPtr[i]); n++) {
        if (colInd[n] == j) {
            value.erase(value.begin() + n);
            colInd.erase(colInd.begin() + n);
            for (unsigned int m = i + 1; m < rowPtr.size(); m++) rowPtr[m]--;
        }
    }
}

void CRSmatrix::printA() {
    for (int valI = 0; valI < rowNum; valI++) {
        for (int valJ = 0; valJ < colNum; valJ++) {
            std::cout << " " << retrieveElement(valI, valJ);
        }
        std::cout << std::endl;
    }
}

int CRSmatrix::ReadRhs(const char *file_name, double *rhs, int size){
    char buf[4096];
    int state = 0;
    int n = 0;
    char *start_ptr = nullptr, *end_ptr = nullptr;
    FILE *file = fopen(file_name, "r");
    if (!file){
        std::cout << "Error: Can't open file!\n";
        return -1;
    }
    int counter = 0;
    while (fgets(buf, 4096, file)) {
        if (state == 0){
            if (!strncmp(buf, "%%", 2))
                continue;
            start_ptr = buf;
            n = (int) strtol(start_ptr, &end_ptr, 10);
            if (start_ptr == end_ptr)
                continue;
            start_ptr = end_ptr;
            if (size != n){
                std::cout << "Error: Size of the rhs part doesn't match with matrix size!\n";
                return -1;
            }
            state = 1;
            continue;
        }
        else if (state == 1){
            start_ptr = buf;
            rhs[counter++] = strtod(start_ptr, &end_ptr);
        }
    }
    return 0;
}

enum {
    PARAMS = 1,
    VALS
};

int CRSmatrix::ReadMatrixFromFile (const char *filename, const int bs) {
    char buf[4096];
    char *start_ptr = nullptr, *end_ptr = nullptr;
    int nr = 0, nnz = 0, nc = 0;
    auto state = PARAMS;
    int row_ptr = 0;
    int count = 0, row_counter = 1;
    int cols = 0;
    double vals = 0.;
    block_size = bs;
    int bs_sqr = block_size * block_size;
    double *block_val;
    std::vector<int> ja;
    double *a;
    std::vector<std::vector<int>> matrix_struct;
    auto rows_ptr = rowPtr.data();
    auto values_ptr = value.data();
    auto cols_ptr = colInd.data();

    FILE *file = fopen(filename, "r");
    if (!file){
        std::cout << "Error: Can't open file!" << "\n";
        return -1;
    }

    while (fgets(buf, 4096, file)){
        if (state == PARAMS){
            if (!strncmp(buf, "%%", 2))
                continue;
            start_ptr = buf;
            nr = (int) strtol(start_ptr, &end_ptr, 10);
            if (start_ptr == end_ptr)
                continue;
            start_ptr = end_ptr;
            nc = (int) strtol(start_ptr, &end_ptr, 10);
            if (start_ptr == end_ptr)
                continue;
            start_ptr = end_ptr;
            nnz = (int) strtol(start_ptr, &end_ptr, 10);
            a = new double[nnz];
            nr /= block_size;
            nnz /= bs_sqr;
            InitMatrix(nr, nnz, block_size);
            state = VALS;
        }
        else if (state == VALS){
            start_ptr = buf;
            row_ptr = (int) strtol(start_ptr, &end_ptr, 10);
            if (start_ptr == end_ptr)
                continue;
            start_ptr = end_ptr;
            cols = (int) strtol(start_ptr, &end_ptr, 10) - 1;
            if (start_ptr == end_ptr)
                continue;
            start_ptr = end_ptr;
            vals = strtod(start_ptr, &end_ptr);
            if (start_ptr == end_ptr)
                continue;

            if (cols % block_size == 0 && row_ptr % block_size == 0){
                ja.push_back(cols / block_size);
            }
            if (row_ptr > row_counter * block_size){
                matrix_struct.push_back(ja);
                ja.clear();
                row_counter++;
            }
            a[count++] = vals;
        }
    }
    matrix_struct.push_back(ja);
    count = 0;
    double *a_block;
    int a_shift;
    for (int i = 0; i < nr; i++){
        int n_cols = matrix_struct[i].size();
        auto row_i = rows_ptr[i];
        rows_ptr[i + 1] = row_i + n_cols;
        a_block = a + row_i * bs_sqr;
        count = 1;
        for (int j = 0; j < n_cols; j++){
            auto col = matrix_struct[i][j];
            if (i != col){
                block_val = values_ptr + row_i * bs_sqr + count * bs_sqr;
                cols_ptr[row_i + count] = col;
                count++;
            }
            else{
                block_val = values_ptr + row_i * bs_sqr;
                cols_ptr[row_i] = i;
            }
            for (int k = 0; k < block_size; k++){
                a_shift = k * n_cols * block_size + j * block_size;
                for (int kk = 0; kk < block_size; kk++){
                    block_val[k * block_size + kk] = a_block[kk + a_shift];
                }
            }
        }
    }
        //std::cout << "pde_num = " << post_diag_row_ind[i] << "\n";

    delete[] a;
    fclose(file);
    return 0;
}

void CRSmatrix::InitMatrix(int N, unsigned int NZ, int blocksize)
{
    int *num;
    num = new int;
    N = *num;
    N = colNum;
    int *nz;
    nz = new int;
    NZ = *nz;
    NZ = value.size();
    int *bs;
    bs = new int;
    blocksize = *bs;
};

void CRSmatrix::DeleteMatrix(const int *N, const unsigned int *NZ, const int *blocksize) {
    delete N;
    delete NZ;
    delete blocksize;
}
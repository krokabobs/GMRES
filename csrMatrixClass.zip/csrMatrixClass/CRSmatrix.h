//
// Created by Павел Филиппов on 02.12.2021.
//

#ifndef CRSMATRIX_H
#define CRSMATRIX_H

#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>

class CRSmatrix {
private:
    int rowNum = 0;
    int colNum = 0;
    int block_size = 0;
    std::vector<double> value;
    std::vector<int> rowPtr;
    std::vector<int> colInd;
public:


    CRSmatrix(std::vector<double> v, std::vector<int> r, std::vector<int> c);

    CRSmatrix(std::string valueAddress, std::string rowPtrAddress, std::string colIndAddress);

    CRSmatrix(int r, int c);

    int getRowSize();
    int getColSize();

    //получение элемента
    double retrieveElement(unsigned int i, unsigned int j);

    //изменение значения
    void changeValue(double x, unsigned int i, unsigned int j);

    //произведение матрицы и вектора
    std::vector<double> productAx(std::vector<double> x);

    //удаление элемента
    void deleteValue(unsigned int i, unsigned int j);

    //вывод матрицы на экран
    void printA();

    int ReadRhs(const char *file_name, double *rhs, int size);
    int ReadMatrixFromFile (const char *filename, int bs);
    void InitMatrix (int N, unsigned int NZ, int blocksize);
    void DeleteMatrix (const int *N, const unsigned int *NZ, const int *blocksize);
};
#endif  //CRSMATRIX_H
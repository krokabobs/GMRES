//
// Created by Павел Филиппов on 03.12.2021.
//
#include <cmath>
#include <iostream>
#include <vector>

#include "CRSmatrix.h"

int main() {

    //std::vector<double> value{-4, 1, 1, 4, -4, 1, 1, -4, 1, 1, -4, 1, 1, 1, -4};
    //std::vector<int> rowPtr{0, 3, 6, 9, 12, 15};
    //std::vector<int> colInd{0, 1, 4, 0, 1, 2, 1, 2, 3, 2, 3, 4, 0, 3, 4};

    //CRSmatrix matrixFromVectors(value, rowPtr, colInd);
    //int ReadRhs("/Users/pavelfilippov/CLionProjects/csrMatrixClass/rhs0", rhs0, 3);
    //int ReadMatrixFromFile ("/Users/pavelfilippov/CLionProjects/csrMatrixClass/full0", 2);
    CRSmatrix matrixFrom3Files("/Users/pavelfilippov/CLionProjects/csrMatrixClass/value.txt", "/Users/pavelfilippov/CLionProjects/csrMatrixClass/rowPtr.txt", "/Users/pavelfilippov/CLionProjects/csrMatrixClass/colInd.txt");

    CRSmatrix A = matrixFrom3Files;
    std::vector<double> b(A.getColSize());
    for (unsigned int i = 0; i < b.size(); i++) {
        b[i] = 0;
    }
    b[0] = 1;

    std::cout << "b = [ ";
    for (unsigned int i = 0; i < b.size(); i++) {
        std::cout << b[i] << ", ";
    }
    std::cout << " ] " << std::endl;

    std::cout << "A = " << std::endl;
    A.printA();
    std::cout << "calculating Ax = b..." << std::endl;
    std::vector<double> x(b.size());
    std::vector<double> productAx(b);
    return 0;
}
